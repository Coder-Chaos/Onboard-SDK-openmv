/*! @file flight-control/main.cpp
 *  @version 3.3
 *  @date Jun 05 2017
 *
 *  @brief
 *  main for Flight Control API usage in a Linux environment.
 *  Provides a number of helpful additions to core API calls,
 *  especially for position control, attitude control, takeoff,
 *  landing.
 *
 *  @Copyright (c) 2016-2017 DJI
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

/*TODO:flight_control_sample will by replace by flight_sample in the future*/
#include "flight_control_demo.hpp"
#include "flight_sample.hpp"

#ifdef OPEN_CV_INSTALLED
#include "opencv2/opencv.hpp"
#include "opencv2/highgui/highgui.hpp"
#include<opencv2/imgproc/imgproc.hpp>

#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
#include <iostream>
#include "facedetectcnn.h"
#include<cmath>

using namespace cv;
static uint8_t detect_buffer[DETECT_BUFFER_SIZE];

#define BUFFER_SIZE (256 * 1024 * 1024)
#define FRAME_WIDTH 320
#define FRAME_HEIGHT 240
#define FRAME_SIZE (FRAME_WIDTH * FRAME_HEIGHT * 3)
#define DETECT_BUFFER_SIZE 0x20000
#endif

static uint64_t get_time(void)
{
	timeval time;
	gettimeofday(&time, nullptr);
	uint64_t result = time.tv_sec;

	return (result * 1000000 + time.tv_usec);
}



using namespace DJI::OSDK;
using namespace DJI::OSDK::Telemetry;

int main(int argc, char** argv) {
  // Initialize variables
  int functionTimeout = 1;

  // Setup OSDK.
  LinuxSetup linuxEnvironment(argc, argv);
  Vehicle* vehicle = linuxEnvironment.getVehicle();
  if (vehicle == NULL) {
    std::cout << "Vehicle not initialized, exiting.\n";
    return -1;
  }

  // Obtain Control Authority
  vehicle->obtainCtrlAuthority(functionTimeout);

  // Display interactive prompt
  std::cout
      << "| Available commands:                                            |"
      << std::endl;
  std::cout
      << "| [a] Monitored Takeoff + Landing                                |"
      << std::endl;
  std::cout
      << "| [b] Monitored Takeoff + Position Control + Landing             |"
      << std::endl;
  std::cout << "| [c] Monitored Takeoff + Position Control + Force Landing "
               "Avoid Ground  |"
            << std::endl;

  char inputChar;
  std::cin >> inputChar;

  switch (inputChar) {
    case 'a':
      monitoredTakeoff(vehicle);
      monitoredLanding(vehicle);
      break;
    case 'b':
      monitoredTakeoff(vehicle);
      DSTATUS("Take off over!\n");

      while(distance_real_h > 0.4f)
      {
        cap>>frame1;
        Rect rect(160, 0, 960, 720);
        Mat frame = frame1(rect);
        //imwrite("my.jpg",frame);
        resize(frame, frame, Size(FRAME_WIDTH, FRAME_HEIGHT), 0, 0, INTER_LINEAR);
        uint64_t start = get_time();
        int *pResults = facedetect_cnn(detect_buffer, (uint8_t *)frame.data, FRAME_WIDTH, FRAME_HEIGHT, 3 * FRAME_WIDTH);
        uint64_t end = get_time();
        std::cout << "detection duration: " << end - start << std::endl;
        //imwrite("my1.jpg",frame);
        //size = frame.size;
        //cout << "size:" << frame.size << endl;
        for(int i = 0; i < (pResults ? *pResults : 0); i++)
        {
          short * p = ((short*)(pResults+1))+142*i;
          int confidence = p[0];
          int x = p[1];
          int y = p[2];
          int w = p[3];
          int h = p[4];
          float distance_real_x;
          float distance_real_y;
          float distance_real_h;
          int distance_img_w;
          int distance_img_h;
          int img_x = 160;
          int img_y = 120;
          float pile = 318;
          float f = 599;
          distance_img_w = x - img_x;
          distance_img_h = y - img_y;

          int dis_min = w < h ? w : h;
  
          distance_real_x = pile/w*distance_img_w;
          distance_real_y = pile/h*distance_img_h;
          distance_real_h = pile/dis_min/3*f;

          cout << "distance_real_x:" << distance_real_x << endl;
          cout << "distance_real_y:" << distance_real_y << endl;
          cout << "distance_real_h:" << distance_real_h << endl;
          moveByPositionOffset(vehicle, distance_real_x, distance_real_y, -0.2, 0);
          DSTATUS("Step 1 over!\n");         
        }
        
        waitKey(20);
      }
      
      monitoredLanding(vehicle);
      break;

    /*! @NOTE: case 'c' only support for m210 V2*/
    case 'c':
      /*! Turn off rtk switch */
      ErrorCode::ErrorCodeType ret;
      ret = vehicle->flightController->setRtkEnableSync(
          FlightController::RtkEnabled::RTK_DISABLE, 1);
      if (ret != ErrorCode::SysCommonErr::Success) {
        DSTATUS("Turn off rtk switch failed, ErrorCode is:%8x", ret);
      } else {
        DSTATUS("Turn off rtk switch successfully");
      }

      /*!  Take off */
      monitoredTakeoff(vehicle);

      /*! Move to higher altitude */
      moveByPositionOffset(vehicle, 0, 0, 30, 0);

      /*! Move a short distance*/
      moveByPositionOffset(vehicle, 10, 0, 0, -30);

      /*! Set aircraft current position as new home location */
      setNewHomeLocation(vehicle);

      /*! Set new go home altitude */
      setGoHomeAltitude(vehicle, 50);

      /*! Move to another position */
      moveByPositionOffset(vehicle, 40, 0, 0, 0);

      /*! go home and  confirm landing */
      goHomeAndConfirmLanding(vehicle, 1);
      break;

    default:
      break;
  }

  return 0;
}
